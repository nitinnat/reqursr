# Fun with Flask

1. Fetching Data with Requests
1. Visualizing with D3
1. Deploying with Dokku

Check out the blog post: [https://realpython.com/blog/python/web-development-with-flask-fetching-data-with-requests/](https://realpython.com/blog/python/web-development-with-flask-fetching-data-with-requests/)